//
// Created by Raf on 28/11/2019.
//

#ifndef DUST_TRANSPORT_EXCEPTION_H
#define DUST_TRANSPORT_EXCEPTION_H

#include "dust_exception.h"

namespace dust::exceptions {
    /**
     * @brief Thrown if an transport throws or encounters an unhandled exception.
     *
     * This is often a nested exception containing the original exception.
     */
    class TransportException : public DustException {
    public:
        explicit TransportException(const std::string &message);
    };
}


#endif //DUST_TRANSPORT_EXCEPTION_H
