//
// Created by Raf on 28/11/2019.
//

#ifndef DUST_DUST_EXCEPTION_H
#define DUST_DUST_EXCEPTION_H


#include <exception>
#include <string>
#include <utility>
#include <iostream>

namespace dust::exceptions {
    /**
     * @brief Base exception used by all DUST exceptions.
     */
    class DustException : public std::exception {
    protected:
        std::string message;

    public:
        /**
         * @brief Initialises the exception using a message that will be returned by
         * dust::exceptions::DustException::what.
         * @param message
         */
        explicit DustException(std::string message) : message(std::move(message)) {}

        [[nodiscard]] const char *what() const noexcept override {
            return message.c_str();
        };

        /**
         *
         * @param e the exception to print
         * @param level the amount of indentation added to the print statement (default = 0)
         */
        static void printToErr(const std::exception &e, int level = 0) {
            std::cerr << std::string(level, ' ') << "exception: " << e.what() << '\n';
            try {
                std::rethrow_if_nested(e);
            } catch (const std::exception &e) {
                printToErr(e, level + 1);
            } catch (...) {

            }
        }
    };
}


#endif //DUST_DUST_EXCEPTION_H
