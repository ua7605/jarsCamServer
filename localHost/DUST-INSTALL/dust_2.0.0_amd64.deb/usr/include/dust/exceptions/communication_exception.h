//
// Created by Raf on 28/11/2019.
//

#ifndef DUST_COMMUNICATION_EXCEPTION_H
#define DUST_COMMUNICATION_EXCEPTION_H

#include "dust_exception.h"

namespace dust::exceptions {
    /**
     * @brief Indicates a failure in the communication stack.
     *
     * For example, dust::Communication::publish uses this to indicate that a channel is not yet configured to publish
     * a message.
     */
    class CommunicationException : public dust::exceptions::DustException {
    public:
        explicit CommunicationException(const std::string &message);
    };
}


#endif //DUST_COMMUNICATION_EXCEPTION_H
