//
// Created by Raf on 28/11/2019.
//

#ifndef DUST_ADDON_EXCEPTION_H
#define DUST_ADDON_EXCEPTION_H

#include "dust_exception.h"

namespace dust::exceptions {
    /**
     * @brief Thrown if an addon throws or encounters an unhandled exception.
     *
     * This is often a nested exception containing the original exception.
     */
    class AddonException : public DustException {
    public:
        explicit AddonException(const std::string &message);
    };
}


#endif //DUST_ADDON_EXCEPTION_H
