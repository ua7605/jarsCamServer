//
// Created by Raf on 28/11/2019.
//

#ifndef DUST_CONFIGURATION_EXCEPTION_H
#define DUST_CONFIGURATION_EXCEPTION_H

#include "dust_exception.h"

namespace dust::exceptions {
    /**
     * @brief Indicates a missing property or an incorrect value of a property.
     *
     * It is used by dust::Configuration::assertHas to indicate a missing property.
     * Addon and transport factories can use this exception to indicate an incorrect value for a property.
     */
    class ConfigurationException : public DustException {
    public:
        explicit ConfigurationException(const std::string &property);

        ConfigurationException(const std::string &property, const std::string &fileName);
    };
}


#endif //DUST_CONFIGURATION_EXCEPTION_H
