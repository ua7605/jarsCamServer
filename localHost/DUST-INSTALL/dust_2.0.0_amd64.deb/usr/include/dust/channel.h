//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_CHANNEL_H
#define DUST_CHANNEL_H

#include "dust/module/addon.h"
#include "dust/module/transport.h"

#include <deque>
#include <memory>

namespace dust {
    /**
     * @brief A Channel is defined by the addon stack and transport.
     */
    class Channel {
    private:
        struct impl;

        std::unique_ptr<impl> _impl;

    public:
        /**
         * @brief Initialises a channel with an empty addon stack, no transport object and no callback.
         */
        Channel();

        virtual ~Channel();

        /**
         * @brief Adds an addon pointer to the bottom of the addon stack (closest to the transport layer).
         *
         * @note This function is <b>not</b> thread-safe.
         * @param addon a pointer to the addon to be added
         */
        void addAddonToStack(dust::Addon *addon);

        /**
         * @brief Sets the transport of this channel.
         *
         * @note This function is <b>not</b> thread-safe.
         * @param pTransport a pointer to the transport
         */
        void setTransport(dust::Transport *pTransport);

        /**
         * @brief Destructs and removes the transport pointer.
         *
         * @note This function is <b>not</b> thread-safe.
         */
        void removeTransport();

        /**
         * @brief Attempts to connect the transport.
         *
         * @note This function is <b>not</b> thread-safe.
         */
        void connect();

        /**
         * @brief Attempts to disconnect the transport.
         *
         * @note This function is <b>not</b> thread-safe.
         */
        void disconnect();

        void flush();

        /**
         * @return the stack of addons
         */
        std::deque<dust::Addon *> &getAddonStack();

        /**
         * @return a pointer to the transport object
         */
        dust::Transport *getTransport();

        /**
         * Calls  (transport layer to application layer)
         * @param payload
         */
        void receiveData(const std::vector<uint8_t> &payload);

        /**
         * Process outgoing data (application layer to transport layer)
         * @param payload
         */
        void sendData(const std::vector<uint8_t> &payload);

        /**
         * @note This function is <b>not</b> thread-safe.
         * @param callbackFunction
         */
        void setCallback(const std::function<void(std::vector<uint8_t>)> &callbackFunction);

    };
}


#endif //DUST_CHANNEL_H
