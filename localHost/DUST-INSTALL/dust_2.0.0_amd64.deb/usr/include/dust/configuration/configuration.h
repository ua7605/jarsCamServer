//
// Created by Raf on 21/11/2019.
//

#ifndef DUST_CONFIGURATION_H
#define DUST_CONFIGURATION_H

#include <memory>
#include <optional>
#include <vector>

namespace dust {
    /**
     * @brief An abstract class used to configure addons and transport.
     *
     * In the current implementation, a JSON implementation is used.
     *
     * All properties of the configuration are accessed using JSON pointers (e.g. <code>/config/array/0</code>).
     */
    class Configuration {
    protected:
        std::shared_ptr<dust::Configuration> defaults = nullptr;

    public:
        Configuration() = default;

        virtual ~Configuration() = default;

        /**
         * @return a shared pointer to the default configuration, or nullptr if absent
         */
        std::shared_ptr<dust::Configuration> getDefaults() {
            return defaults;
        };

        /**
         * @brief Sets the defaults of this configuration to the provided configuration file.
         *
         * This default configuration is used if a property is accessed, but does not exist in this configuration.
         *
         * @param newDefaults the default configuration
         */
        void setDefaults(std::shared_ptr<dust::Configuration> newDefaults) {
            this->defaults = std::move(newDefaults);
        };

        /**
         * @brief Checks if all provided properties are present in this configuration and returns a corresponding boolean.
         *
         * This function can be used as a one-liner using a vector initializer list:
         * @code
         * has({"property_a", "property_b"})
         * @endcode
         *
         * @param properties the properties to check
         * @return true if all properties are present, false if otherwise
         */
        virtual bool has(const std::vector<std::string> &properties) = 0;


        /**
         * @brief Checks if all provided properties are present in this configuration and throws a dust::exceptions::ConfigurationException if a property is absent.
         *
         * This function can be used as a one-liner using a vector initializer list:
         * @code
         * assertHas({"property_a", "property_b"})
         * @endcode
         *
         * @param properties the properties to check
         * @throw dust::exceptions::ConfigurationException if a property is absent
         */
        virtual void assertHas(const std::vector<std::string> &properties) = 0;

        /**
         * @brief Returns a configuration of a subsection defined by the path argument.
         *
         * @param subPath the JSON-type pointer to the subsection
         * @return a configuration of the subsection
         */
        virtual std::shared_ptr<dust::Configuration> getSubConfiguration(std::string subPath) = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a string representation of the value of the property
         */
        virtual std::optional<std::string> getString(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a boolean representation of the value of the property
         */
        virtual std::optional<bool> getBool(const std::string &pat = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a int representation of the value of the property
         */
        virtual std::optional<int> getInt(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return an unsigned int representation of the value of the property
         */
        virtual std::optional<unsigned int> getUnsignedInt(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a 8-bit int representation of the value of the property
         */
        virtual std::optional<int8_t> getInt8(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a 16-bit int representation of the value of the property
         */
        virtual std::optional<int16_t> getInt16(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a 32-bit int representation of the value of the property
         */
        virtual std::optional<int32_t> getInt32(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a 64-bit int representation of the value of the property
         */
        virtual std::optional<int64_t> getInt64(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a unsigned 8-bit int representation of the value of the property
         */
        virtual std::optional<uint8_t> getUnsignedInt8(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a unsigned 16-bit int representation of the value of the property
         */
        virtual std::optional<uint16_t> getUnsignedInt16(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a unsigned 32-bit int representation of the value of the property
         */
        virtual std::optional<uint32_t> getUnsignedInt32(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return a unsigned 64-bit int representation of the value of the property
         */
        virtual std::optional<uint64_t> getUnsignedInt64(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return true if the value defined by this property is an array
         */
        virtual bool isArray(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer to the property
         * @return true if the value defined by this property is an array
         */
        virtual size_t getArraySize(const std::string &path = "") = 0;

        /**
         * @param path a JSON-type pointer
         * @return a vector of all property keys at this path
         */
        virtual std::vector<std::string> getProperties(const std::string &path = "") = 0;
    };
}


#endif //DUST_CONFIGURATION_H
