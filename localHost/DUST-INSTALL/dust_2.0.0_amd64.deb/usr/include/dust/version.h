//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_VERSION_H
#define DUST_VERSION_H

#include <string>
#include <optional>

namespace dust {
    /**
     * @brief A semver wrapper with utility functions to check compatibility.
     */
    class Version {
    private:
        std::optional<unsigned int> major;
        std::optional<unsigned int> minor;
        std::optional<unsigned int> patch;

    public:
        /**
         * @brief Initialises the version with major version.
         *
         * Minor and patch are set to wildcard.
         *
         * @param major the major version
         */
        explicit Version(unsigned int major) noexcept;

        /**
         * @brief Initialises the version with major and minor version.
         *
         * Patch is set to wildcard.
         *
         * @param major the major version
         * @param minor the minor version
         */
        Version(unsigned int major, unsigned int minor) noexcept;

        /**
         * @brief Initialises the version with major, minor and patch version.
         *
         * @param major the major version
         * @param minor the minor version
         * @param patch the patch version
         */
        Version(unsigned int major, unsigned int minor, unsigned int patch) noexcept;

        static dust::Version DUST_VERSION;

        /**
         * @return the major version
         */
        std::optional<unsigned int> getMajor();

        /**
         * @return the minor version
         */
        std::optional<unsigned int> getMinor();

        /**
         * @return the version version
         */
        std::optional<unsigned int> getPatch();

        /**
         * @return a version string formatted as MAJOR.MINOR.PATCH
         */
        std::string getVersionString();

        bool isInRange(const Version &lower, const Version &higher);

        bool operator==(const Version &rhs) const;

        bool operator!=(const Version &rhs) const;

        bool operator<(const Version &rhs) const;

        bool operator>(const Version &rhs) const;

        bool operator<=(const Version &rhs) const;

        bool operator>=(const Version &rhs) const;
    };
}

#endif //DUST_VERSION_H
