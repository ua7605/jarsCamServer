//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_CORE_H
#define DUST_CORE_H

#include "channel.h"
#include "module/module_registry.h"
#include "module/module_loader.h"

#include <string>
#include <functional>
#include <map>
#include <thread>

namespace dust {
    /**
     * @brief The main entrypoint to the DUST library.
     *
     * It keeps track of the registered channels, callbacks to the application, and offers thread-safe functions to
     * interact with the channels.
     */
    class Core {
    private:
        struct impl;

        std::unique_ptr<impl> _impl;

    public:

        /**
         * @brief Initialises a new DUST block with the given name and the path to the directory that contains DUST modules.
         *
         * This name is used by the configurator to select which configuration properties are selected.
         * The modules directory is used by dust::Communication::setup() to preload the libraries and detect which addons and transports they offer.
         *
         * @param name The name of the block
         * @param modulesDirectory The path to the directory that contains the DUST modules
         */
        explicit Core(std::string name, std::string modulesDirectory = "./modules");

        virtual ~Core();

        /**
         * @brief This function calls the callback function defined by the application using dust::Communication::registerListener(channel, callback).
         *
         * It is used by dust::Transport to notify the application of an incoming message.
         *
         * @param channel The channel on which the message is received
         * @param payload The byte payload of the message
         */
        void receiveMessage(const std::string &channel, const std::vector<uint8_t> &payload);

        /**
         * @brief Publishes a message on a given channel.
         *
         * @param channel The channel to send the message on
         * @param payload The bytes payload of the message
         * @throw dust::exceptions::CommunicationException if the channel is not configured
         */
        void publish(const std::string &channel, const std::vector<uint8_t> &payload);

        /**
         * @brief Registers a callback function that will be called when a message is received on the given channel.
         *
         * The supplied callback function is used by dust::Communication::receiveMessage(const std::string &channel, const std::vector<uint8_t> &payload) to notify the application of a message.
         *
         * @param channel The channel to register on
         * @param callback The callback function that takes a vector of uint8_t
         * @return true if the callback is successfully registered, false if the provided channel key already has a callback set
         * @see registerListener(const std::string &channel, void (*callback)(std::vector<uint8_t>))
         */
        bool registerListener(const std::string &channel, const std::function<void(std::vector<uint8_t>)> &callback);

        /**
         * @brief Registers a callback function that will be called when a message is received on the given channel.
         *
         * The supplied callback function is used by dust::Communication::receiveMessage(const std::string &channel, const std::vector<uint8_t> &payload) to notify the application of a message.
         *
         * @param channel The channel to register on
         * @param callback The callback function that takes a vector of uint8_t
         * @return True if the callback is successfully registered
         * @see registerListener(const std::string &channel, const std::function<void(std::vector<uint8_t>)> &callback)
         */
        bool registerListener(const std::string &channel, void (*callback)(std::vector<uint8_t>));

        /**
         * @brief Adds the given channel with a given name to this instance.
         *
         * If a channel with the same name has already been added, the previous instance will be destructed and removed.
         *
         * @param channelName The identifier of the channel
         * @param channel The pointer to the Channel instance
         */
        void addChannel(const std::string &channelName, std::unique_ptr<dust::Channel> channel);

        /**
         * @brief Removes a channel from this Communication object.
         *
         * @param channelName The channel name
         */
        void removeChannel(const std::string &channelName);

        /**
         * @brief Returns an optional containing a shared pointer to the dust::Channel denoted by the given channel name, or an empty optional otherwise.
         *
         * @param channelName The channel name
         * @return An optional containing a channel object
         */
        std::unique_ptr<dust::Channel> &getChannel(const std::string &channelName);

        /**
         * @return a map of the configured channels
         */
        const std::map<std::string, std::unique_ptr<dust::Channel>> &getChannels();

        /**
         * @brief This function loops through all dynamic libraries contained in the modules directory (defined by dust::Communication::Communication), and detects which addons and transports they offer.
         *
         * All checked libraries are unloaded after running this function.
         *
         * @note Dynamic libraries in the modules directory are not searched recursively. Only the libraries contained in the modules directory are loaded.
         */
        void setup();

        /**
         * @brief Loops through all defined channels and attempts to connect them.
         *
         * @note This function is thread-safe
         */
        void connect();

        /**
         * @brief Loops through all defined channels and attempts to disconnect them.
         *
         * @note This function is thread-safe
         */
        void disconnect();

        /**
         * @brief Sets the configuration file of the DUST library and .
         *
         * @note This function is thread-safe
         * @param path The path to the configuration file
         */
        void setConfigurationFile(const std::string &path);

        /**
         * @brief Reloads the configuration file set by dust::Communication::setConfigurationFile.
         *
         * @note This function is thread-safe
         * @param path The path to the configuration file
         */
        void reloadConfigurationFile();

        /**
         * @brief Starts watching the configuration file set by setConfigurationFile and automatically reconfigure the stack upon modification.
         */
        void watchConfigurationFile();

        /**
         * @brief Parses the configuration at the provided path immediately.
         *
         * @note This function is <b>not</b> thread-safe! Ideally, it should only be executed from the main thread.
         * @param path The path to the configuration file
         */
        void parseConfigurationFile(const std::string &path);

        /**
         * @return The name of the DUST block, as defined by dust::Communication::Communication.
         */
        const std::string &getName();

        /**
         * @return The module registry
         */
        ModuleRegistry &getModuleRegistry();

        /**
         * @return The module loader
         */
        ModuleLoader &getModuleLoader();

        /**
         * @brief This function performs housekeeping tasks, like thread-safe (dis)connecting and (re)configuration of channels.
         *
         * The order of tasks is:
         *  1. Disconnect
         *  2. (Re)configure
         *  3. Connect
         */
        void cycleOnce();

        /**
         * @brief Blocks until one of the thread-safe methods is called (e.g. dust::Communication:connect).
         */
        void waitForChange();

        /**
         * @brief Starts a new thread that executed dust::Communication::waitForChange and dust::Communication::cycleOnce until dust::Communication::cycleStop is called.
         * @return The thread object
         */
        std::thread cycleForever();

        /**
         * Stops all threads returned by dust::Communication::cycleForever.
         */
        void cycleStop();
    };
}


#endif //DUST_CORE_H
