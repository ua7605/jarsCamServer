//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_ADDON_H
#define DUST_ADDON_H

#include <functional>

namespace dust {
    /**
     * @brief An Addon transforms data coming from or going to the transport layer and is stored in the addon stack
     * of a Channel.
     *
     * Modules can make their implementation of Addon and offer it through an AddonFactory.
     *
     * @see AddonFactory
     */
    class Addon {
    private:
        std::string typeName;

    protected:
        std::function<void(std::vector<uint8_t>)> send;
        std::function<void(std::vector<uint8_t>)> receive;

    public:
        explicit Addon(std::string typeName) : typeName(std::move(typeName)) {}

        virtual ~Addon() = default;

        const std::string &getTypeName() {
            return typeName;
        }

        void setSendCallback(const std::function<void(std::vector<uint8_t>)> &next) {
            Addon::send = next;
        }

        void setReceiveCallback(const std::function<void(std::vector<uint8_t>)> &next) {
            Addon::receive = next;
        }

        virtual void sendData(const std::vector<uint8_t> &payload) = 0;

        virtual void receiveData(const std::vector<uint8_t> &payload) = 0;

        virtual void flush() = 0;
    };
}


#endif //DUST_ADDON_H
