//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_TRANSPORT_H
#define DUST_TRANSPORT_H

#include <functional>

namespace dust {
    /**
     * @brief A Transport implementation allows the application to communicate with the outside world.
     *
     * Modules can make their implementation of Transport and offer it through an TransportFactory.
     *
     * @see TransportFactory
     */
    class Transport {
    private:
        std::string typeName;
        std::function<void(std::vector<uint8_t>)> receiveCallback;

    public:
        explicit Transport(std::string typeName) : typeName(std::move(typeName)) {}

        virtual ~Transport() = default;

        const std::string &getTypeName() {
            return typeName;
        }

        virtual void connect() = 0;

        virtual void disconnect() = 0;

        virtual void sendData(const std::vector<uint8_t> &payload) = 0;

        virtual void flush() = 0;

        std::function<void(std::vector<uint8_t>)> &getReceiveCallback() {
            return receiveCallback;
        }

        void setReceiveCallback(const std::function<void(std::vector<uint8_t>)> &recvCallback) {
            this->receiveCallback = recvCallback;
        }
    };
}


#endif //DUST_TRANSPORT_H
