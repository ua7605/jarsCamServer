//
// Created by Raf on 09/10/2019.
//

#ifndef DUST_ADDON_FACTORY_H
#define DUST_ADDON_FACTORY_H

#include "addon.h"
#include "../configuration/configuration.h"

namespace dust {
    /**
     * @brief An AddonFactory creates Addon instances based on the supplied Configuration.
     *
     * An AddonFactory is implemented by Module's and added to the system using the ModuleRegistry.
     *
     * @see Module
     * @see ModuleRegistry
     */
    class AddonFactory {
    public:

        /**
         * @brief Returns an instance of the implementation of Addon defined by this factory and configures it
         * using the supplied Configuration.
         *
         * @param configuration the Transport configuration
         * @return an new instance of Addon
         */
        virtual dust::Addon *getAddon(dust::Configuration &configuration) = 0;
    };
}


#endif //DUST_ADDON_FACTORY_H
