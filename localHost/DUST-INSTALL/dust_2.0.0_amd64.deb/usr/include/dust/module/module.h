//
// Created by Raf on 30/09/2019.
//

#ifndef DUST_MODULE_H
#define DUST_MODULE_H

#include "module_registry.h"

#ifdef _WIN32
#define EXPORTED  __declspec( dllexport )
#else
#define EXPORTED
#endif

/**
 * @brief Adds an export to the dynamic library that allows the dust::ModuleLoader to load the library containing
 * this macro.
 * @param name the class name of the dust::Module implementation
 */
#define EXPORT_MODULE(name) \
    extern "C" { \
        EXPORTED dust::Module *DUST_MODULE_INIT() { \
            auto *addon = new name(); \
            return addon; \
        } \
    }

namespace dust {
    /**
     * @brief A base class for modules. A Module offers AddonFactory's and/or TransportFactory's.
     *
     * It is exported to DUST using the EXPORT_MODULE macro.
     */
    class Module {
    private:
        std::vector<std::string> addons;
        std::vector<std::string> transports;

    protected:
        Module(std::vector<std::string> addons, std::vector<std::string> transports) : addons(std::move(addons)),
                                                                                       transports(
                                                                                               std::move(transports)) {}

    public:
        virtual ~Module() = default;

        std::vector<std::string> getAddons() {
            return addons;
        }

        std::vector<std::string> getTransports() {
            return transports;
        }

        /**
         * @brief Called by ModuleLoader and used to setup the Module and register factories to the ModuleRegistry.
         * @param moduleRegistry the module registry
         */
        virtual void setup(ModuleRegistry *moduleRegistry) = 0;


        /**
         * @brief Called by ModuleLoader and used to tear down the Module and unregister factories from the
         * ModuleRegistry.
         * @param moduleRegistry the module registry
         */
        virtual void cleanup(ModuleRegistry *moduleRegistry) = 0;
    };
}


#endif //DUST_MODULE_H
