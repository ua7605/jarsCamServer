//
// Created by Raf on 03/10/2019.
//

#ifndef DUST_MODULE_LOADER_H
#define DUST_MODULE_LOADER_H

#include "dust/module/module.h"

#include <optional>
#include <utility>

namespace dust {
    /**
     * @brief The ModuleLoader keeps track of dynamic libraries.
     *
     * It is responsible for loading and unloading dynamic libraries, and stores information of the dynamic libraries.
     */
    class ModuleLoader {
    private:
        struct AddonInfo {
            AddonInfo(std::string location, int usageCount) : location(std::move(location)), usageCount(usageCount) {};

            std::string location;
            int usageCount;
        };

        struct ModuleInfo {
            void *handle = nullptr;
            dust::Module *modulePtr = nullptr;
        };

        dust::ModuleRegistry *moduleRegistry;

        /**
         * Maps addon name to module library location
         */
        std::map<std::string, std::shared_ptr<AddonInfo>> addonLocations;
        /**
         * Maps transport name to module library location
         */
        std::map<std::string, std::shared_ptr<AddonInfo>> transportLocations;
        /***
         * Maps module library file name to struct of library handle and module pointer
         */
        std::map<std::string, ModuleInfo *> modules;

        std::optional<dust::Module *> getModule(const std::string &fileName);

    public:
        explicit ModuleLoader(ModuleRegistry *moduleRegistry);

        void walkLibraries(const std::string &path);

        virtual ~ModuleLoader();

        std::optional<dust::Module *> loadModule(const std::string &path);

        void unloadModule(const std::string &fileName);

        bool isLoaded(const std::string &fileName);

        std::optional<dust::Module *> loadModuleOfAddon(const std::string &addon);

        std::optional<dust::Module *> loadModuleOfTransport(const std::string &transport);

        void unloadModuleOfAddon(const std::string &addon);

        void unloadModuleOfTransport(const std::string &transport);
    };
}


#endif //DUST_MODULE_LOADER_H
