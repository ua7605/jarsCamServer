//
// Created by Raf on 01/10/2019.
//

#ifndef DUST_MODULE_REGISTRY_H
#define DUST_MODULE_REGISTRY_H

#include "transport_factory.h"
#include "addon_factory.h"

#include <string>
#include <map>

namespace dust {
    /**
     * @brief A registry of AddonFactory's and TransportFactory's.
     *
     * Modules can add factories using their Module::setup method.
     */
    class ModuleRegistry {
    private:
        std::map<std::string, dust::AddonFactory *> addonFactoryMap;
        std::map<std::string, dust::TransportFactory *> transportFactoryMap;
    public:
        ModuleRegistry();

        void registerAddonFactory(const std::string &name, dust::AddonFactory *addon);

        void registerTransportFactory(const std::string &name, dust::TransportFactory *transport);

        void unregisterAddonFactory(const std::string &name);

        void unregisterTransportFactory(const std::string &name);

        dust::AddonFactory *getAddonFactory(const std::string &name);

        dust::TransportFactory *getTransportFactory(const std::string &name);
    };
}


#endif //DUST_MODULE_REGISTRY_H
